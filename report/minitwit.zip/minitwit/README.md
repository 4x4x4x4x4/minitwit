# Intro
This program is a twitter-clone, called minitwit made for the course DevOps, Software Evolution and Software Maintenance, BSc (Spring 2025) with the coursecode: BSDSESM1KU

# Running the program
To run the program run the following command:
```
$ docker compose up --build 
```
This starts the program at `localhost:5000`