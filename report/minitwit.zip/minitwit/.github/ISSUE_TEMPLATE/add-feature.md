---
name: Add feature
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

Short description of the feature


Description of the technical services (i.e. SQLite, DigitalOcean)


Link to where the task was mentioned in the course:
